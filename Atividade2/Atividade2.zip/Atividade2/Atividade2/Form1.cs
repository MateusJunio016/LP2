﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{

    public partial class Form1 : Form
    {
        Double Num1, Num2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out Num1))
                {
                MessageBox.Show("ERRO! Número 1 Inválido!");
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("ERRO! Número 2 Inválido!");
            }
        }

        private void btnSubtração_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Num1) &&
                (double.TryParse(txtNum2.Text, out Num2)))
                {
                resultado = Num1 - Num2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("ERRO! Números Inválidos!");
            }
        }

        private void btnAdição_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtNum1.Text, out Num1) &&
                (double.TryParse(txtNum2.Text, out Num2)))
                {
                resultado = Num1 + Num2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("ERRO! Números Inválidos!");
            }
        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Num1) &&
                (double.TryParse(txtNum2.Text, out Num2)))
            {
                if (Num2 == 0)
                {
                    MessageBox.Show("ERRO! Não é possível dividir por 0!");
                }
                else
                {
                    resultado = Num1 / Num2;
                    txtResultado.Text = resultado.ToString();
                }
            }

        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();

        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtNum1.Text, out Num1) &&
                (double.TryParse(txtNum2.Text, out Num2)))
            {
                resultado = Num1 * Num2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("ERRO! Números Inválidos!");
            }
        }
    }
}
