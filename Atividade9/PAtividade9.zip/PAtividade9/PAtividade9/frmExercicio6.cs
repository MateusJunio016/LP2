﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] n = new string[3];
            double[] validated = new double[3];
            string auxiliar = "";
            for (var i = 0; i < n.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite seu nome completo na posição " + (i + 1));
                string auxiliar2 = auxiliar;
                if (double.TryParse(auxiliar, out validated[i]) || auxiliar == "")
                {
                    MessageBox.Show("Erro! Nome inválido");
                    i--;
                }

                else
                {
                    int contador = 0;
                    while (contador < auxiliar.Length)
                    {
                        auxiliar = auxiliar.Replace(" ", "");
                        if (Char.IsLetter(auxiliar[contador]))
                        {
                            contador++;
                        }

                    }
                    lstbxValores.Items.Add("\n" + "• nome: " + auxiliar2 + " tem " + contador + " caracteres");
                }
            }
        }
    }
}
