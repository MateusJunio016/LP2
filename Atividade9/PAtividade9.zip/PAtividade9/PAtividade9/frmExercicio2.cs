﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int[] quantidade = new int[10];
            double[] precos = new double[10];
            string auxiliar = "";
            string auxiliar2 = "";
            double mensal = 0.0;

            for (var i = 0; i < quantidade.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade vendida do item:" + (i + 1),
                    "Entrada de Dados");

                if (!int.TryParse(auxiliar, out quantidade[i]))
                {
                    MessageBox.Show("Erro! Quantidade inválida");
                    i--;
                }

            }
            for (var j = 0; j < 10; j++)
            {
                auxiliar2 = Interaction.InputBox("Digite o preço do item:" + (j + 1),
                    "Entrada de Dados");
                if (!double.TryParse(auxiliar2, out precos[j]))
                {
                    MessageBox.Show("Erro! Preço Inválido");
                    j--;

                }
            }

            int qtde1 = quantidade[0];
            double prc1 = precos[0];
            double total1 = qtde1 * prc1;

            int qtde2 = quantidade[1];
            double prc2 = precos[1];
            double total2 = qtde2 * prc2;

            int qtde3 = quantidade[2];
            double prc3 = precos[2];
            double total3 = qtde3 * prc3;

            int qtde4 = quantidade[3];
            double prc4 = precos[3];
            double total4 = qtde4 * prc4;

            int qtde5 = quantidade[4];
            double prc5 = precos[4];
            double total5 = qtde5 * prc5;

            int qtde6 = quantidade[5];
            double prc6 = precos[5];
            double total6 = qtde6 * prc6;

            int qtde7 = quantidade[6];
            double prc7 = precos[6];
            double total7 = qtde7 * prc7;

            int qtde8 = quantidade[7];
            double prc8 = precos[7];
            double total8 = qtde8 * prc8;

            int qtde9 = quantidade[8];
            double prc9 = precos[8];
            double total9 = qtde9 * prc9;

            int qtde10 = quantidade[9];
            double prc10 = precos[9];
            double total10 = qtde10 * prc10;

            mensal += total1 + total2 + total3 + total4 + total5 + total6 + total7 + total8 +
                total9 + total10;

            MessageBox.Show("Faturamento mensal: R$" + mensal, "Faturamento mensal");
        }

    }
}

