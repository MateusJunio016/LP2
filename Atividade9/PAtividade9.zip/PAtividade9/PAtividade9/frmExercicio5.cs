﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[20, 3];
            string auxiliar = "";
            int contador = 0;
            string valor = "";
            double media = 0.0;
            double anterior = 0.0;
            double soma = 0.0;

            for(var aluno = 0; aluno < 20; aluno++)
            {
                for(var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (nota + 1) + " do aluno: " + (aluno + 1),
                    "Entrada de Dados");


                    if (!double.TryParse(auxiliar, out vetor[aluno, nota]) ||
                        Double.Parse(auxiliar) > 10 || Double.Parse(auxiliar) < 0)
                    {
                        MessageBox.Show("Erro! Nota Inválida");
                        nota--;
                    }
                    else
                    {
                        contador += 1;
                        media += vetor[aluno, nota];
                    }
                    if (contador % 3 == 0)
                    {
                        soma += anterior;
                        anterior = anterior - soma + ((media / 3) - anterior);
                        valor = valor + "Aluno " + (aluno + 1) + " média = " + anterior + "\n";
                    }
                }
            }
            MessageBox.Show(valor, "Notas");
        }
    }
}
