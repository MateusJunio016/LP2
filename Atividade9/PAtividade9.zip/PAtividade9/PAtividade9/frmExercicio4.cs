﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade9
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnLista_Click(object sender, EventArgs e)
        {
            List<string> arrString = new List<string>(new string[] {"Ana", "André", "Débora", "Fátima",
                "João", "Janete", "Otávio","Marcelo", "Pedro", "Thaís"});

            MessageBox.Show(arrString[0] + ", " + arrString[1] + ", " + arrString[2] + ", " +
                arrString[3] + ", " + arrString[4] + ", " + arrString[5] + ", " + arrString[6] +
                 ", " + arrString[7] + ", " + arrString[8] + ", " + arrString[9], "Lista de Alunos");
        }

        private void btnLista2_Click(object sender, EventArgs e)
        {
            string[] arrString = new string[10] {"Ana", "André", "Débora", "Fátima",
                "João", "Janete", "Otávio","Marcelo", "Pedro", "Thaís"};

            var lista = arrString.ToList();
            lista.RemoveAt(6);
            arrString = lista.ToArray();
            var result = String.Join(", ", arrString);
            MessageBox.Show(result, "Lista de Alunos Atualizada");
        }
    }
}
