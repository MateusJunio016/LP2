﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContatos0030482111033
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Trabalho feito por: Mateus Junio da Silva Miranda \n" +
                "RA: 0030482111033 \n" + "Fatec Sorocaba - Linguagem de Programação II - Linguagem Visual Basic (VB)", "Sobre");
        }
    }
}
