﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P30482111033
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[3, 4];
            string auxiliar = "";
            int contador = 0;
            string valor = "";
            string semana = "";
            double media = 0.0;
            double anterior = 0.0;
            double soma = 0.0;
            string resultado = "";
            double final = 0.0;


            for (var mes = 0; mes < 3; mes++)
            {
                for (var total = 0; total < 4; total++)
                {
                    auxiliar = Interaction.InputBox("Digite o total da semana " + (total + 1) + " mês " + (mes + 1),
                    "Entrada de Dados");


                    if (!double.TryParse(auxiliar, out vetor[mes, total]) || Double.Parse(auxiliar) < 0)
                    {
                        MessageBox.Show("Erro! Valor Inválido");
                        total--;
                    }
                    else
                    {
                        contador ++;
                        media += vetor[mes, total];
                        semana = semana + "Total do mês " + (mes + 1) + " Semana: " + (total + 1)
                            + " R$" + Double.Parse(auxiliar).ToString("N2") + "\n" + valor;
                        valor = "";

                        if (contador % 4 == 0)
                        {

                            soma += anterior;
                            anterior = anterior - soma + media - anterior;
                            valor = valor + ">> Total do mês: " + " R$" + anterior.ToString("N2") + "\n" +
                                "-----------------------" + "\n";
                            resultado = semana + valor;
                            final += anterior;
                        }

                    }
                }
            }
            MessageBox.Show(resultado + ">> Total Geral: R$" + final.ToString("N2"), "Total de valores");
        }
    }
}
