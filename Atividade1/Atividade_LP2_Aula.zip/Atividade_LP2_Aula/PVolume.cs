﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_LP2_Aula
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        { 
            if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtRaio.Text, out raio))
            {
                double volume;

                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");

            }
            else
            {
                MessageBox.Show("Erro! Valores Inválidos!");
                txtRaio.Focus();
            }
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnLimpar_Validated(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;

            txtRaio.Focus();
        }

        private void btnCalcular_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;

            txtRaio.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!((e.KeyChar >= (char)48) && (e.KeyChar <= (char)57)))
            {
                e.KeyChar = '\0';
            }
        }

        private void txtVolume_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Erro! Valor de raio inválido!");
                txtRaio.Text = "";
                txtRaio.Focus();
            }
            else
            if (raio <= 0)
            {
                MessageBox.Show("Erro! Raio deve ser maior que zero!");
                txtRaio.Text = "";
                txtRaio.Focus();
            }
        }
    }
}
