﻿
namespace PVolume
{
	partial class Form1
	{
		/// <summary>
		/// Variável de designer necessária.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpar os recursos que estão sendo usados.
		/// </summary>
		/// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código gerado pelo Windows Form Designer

		/// <summary>
		/// Método necessário para suporte ao Designer - não modifique 
		/// o conteúdo deste método com o editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtRaio = new System.Windows.Forms.TextBox();
			this.txtAltura = new System.Windows.Forms.TextBox();
			this.txtVolume = new System.Windows.Forms.TextBox();
			this.btnCalcular = new System.Windows.Forms.Button();
			this.btnLimpar = new System.Windows.Forms.Button();
			this.btnSair = new System.Windows.Forms.Button();
			this.lblRaio = new System.Windows.Forms.Label();
			this.lblAltura = new System.Windows.Forms.Label();
			this.lblVolume = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtRaio
			// 
			this.txtRaio.Location = new System.Drawing.Point(110, 84);
			this.txtRaio.Name = "txtRaio";
			this.txtRaio.Size = new System.Drawing.Size(100, 20);
			this.txtRaio.TabIndex = 3;
			this.txtRaio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txtRaio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRaio_KeyPress);
			// 
			// txtAltura
			// 
			this.txtAltura.Location = new System.Drawing.Point(110, 118);
			this.txtAltura.Name = "txtAltura";
			this.txtAltura.Size = new System.Drawing.Size(100, 20);
			this.txtAltura.TabIndex = 4;
			this.txtAltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txtAltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAltura_KeyPress);
			// 
			// txtVolume
			// 
			this.txtVolume.Location = new System.Drawing.Point(110, 154);
			this.txtVolume.Name = "txtVolume";
			this.txtVolume.ReadOnly = true;
			this.txtVolume.Size = new System.Drawing.Size(100, 20);
			this.txtVolume.TabIndex = 5;
			this.txtVolume.Tag = "";
			this.txtVolume.Text = "Volume";
			this.txtVolume.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txtVolume.Validated += new System.EventHandler(this.txtVolume_Validated);
			// 
			// btnCalcular
			// 
			this.btnCalcular.Font = new System.Drawing.Font("SF Distant Galaxy", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCalcular.Location = new System.Drawing.Point(16, 200);
			this.btnCalcular.Name = "btnCalcular";
			this.btnCalcular.Size = new System.Drawing.Size(79, 23);
			this.btnCalcular.TabIndex = 6;
			this.btnCalcular.Text = "Calcular";
			this.btnCalcular.UseVisualStyleBackColor = true;
			this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Validated);
			this.btnCalcular.Validated += new System.EventHandler(this.btnCalcular_Validated);
			// 
			// btnLimpar
			// 
			this.btnLimpar.Font = new System.Drawing.Font("SF Distant Galaxy", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLimpar.Location = new System.Drawing.Point(110, 200);
			this.btnLimpar.Name = "btnLimpar";
			this.btnLimpar.Size = new System.Drawing.Size(85, 23);
			this.btnLimpar.TabIndex = 7;
			this.btnLimpar.Text = "Limpar";
			this.btnLimpar.UseVisualStyleBackColor = true;
			this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
			this.btnLimpar.Validated += new System.EventHandler(this.btnLimpar_Click);
			// 
			// btnSair
			// 
			this.btnSair.Font = new System.Drawing.Font("SF Distant Galaxy", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSair.Location = new System.Drawing.Point(209, 200);
			this.btnSair.Name = "btnSair";
			this.btnSair.Size = new System.Drawing.Size(81, 23);
			this.btnSair.TabIndex = 8;
			this.btnSair.Text = "Sair";
			this.btnSair.UseVisualStyleBackColor = true;
			this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
			this.btnSair.Validated += new System.EventHandler(this.btnSair_Click);
			// 
			// lblRaio
			// 
			this.lblRaio.AutoSize = true;
			this.lblRaio.Font = new System.Drawing.Font("SF Distant Galaxy", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRaio.ForeColor = System.Drawing.SystemColors.Control;
			this.lblRaio.Location = new System.Drawing.Point(61, 87);
			this.lblRaio.Name = "lblRaio";
			this.lblRaio.Size = new System.Drawing.Size(34, 11);
			this.lblRaio.TabIndex = 9;
			this.lblRaio.Text = "Raio";
			this.lblRaio.Validated += new System.EventHandler(this.lblRaio_Validated);
			// 
			// lblAltura
			// 
			this.lblAltura.AutoSize = true;
			this.lblAltura.Font = new System.Drawing.Font("SF Distant Galaxy", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAltura.ForeColor = System.Drawing.SystemColors.Control;
			this.lblAltura.Location = new System.Drawing.Point(49, 123);
			this.lblAltura.Name = "lblAltura";
			this.lblAltura.Size = new System.Drawing.Size(55, 11);
			this.lblAltura.TabIndex = 10;
			this.lblAltura.Text = "Altura";
			this.lblAltura.Validated += new System.EventHandler(this.lblAltura_Validated);
			// 
			// lblVolume
			// 
			this.lblVolume.AutoSize = true;
			this.lblVolume.Font = new System.Drawing.Font("SF Distant Galaxy", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVolume.ForeColor = System.Drawing.SystemColors.Control;
			this.lblVolume.Location = new System.Drawing.Point(50, 159);
			this.lblVolume.Name = "lblVolume";
			this.lblVolume.Size = new System.Drawing.Size(54, 11);
			this.lblVolume.TabIndex = 11;
			this.lblVolume.Text = "Volume";
			this.lblVolume.Validated += new System.EventHandler(this.lblVolume_Validated);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.DarkSlateBlue;
			this.ClientSize = new System.Drawing.Size(313, 295);
			this.Controls.Add(this.lblVolume);
			this.Controls.Add(this.lblAltura);
			this.Controls.Add(this.lblRaio);
			this.Controls.Add(this.btnSair);
			this.Controls.Add(this.btnLimpar);
			this.Controls.Add(this.btnCalcular);
			this.Controls.Add(this.txtVolume);
			this.Controls.Add(this.txtAltura);
			this.Controls.Add(this.txtRaio);
			this.Name = "Form1";
			this.Text = "Cálculo do Volume do Cilindro";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.TextBox txtRaio;
		private System.Windows.Forms.TextBox txtAltura;
		private System.Windows.Forms.TextBox txtVolume;
		private System.Windows.Forms.Button btnCalcular;
		private System.Windows.Forms.Button btnLimpar;
		private System.Windows.Forms.Button btnSair;
		private System.Windows.Forms.Label lblRaio;
		private System.Windows.Forms.Label lblAltura;
		private System.Windows.Forms.Label lblVolume;
	}
}

