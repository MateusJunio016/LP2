﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Salario : System.Windows.Forms.Form
    {
        public Salario()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double descInss = 0.0;
            double descIrff = 0.0;
            double salFam = 0.0;
            double salLiq = 0.0;
            double salBruto = 0.0;

            if ((txtFunc.Text == "") || (txtFunc.Text.Length < 3))
                MessageBox.Show("ERRO! Nome do funcionário inválido");

            else if (double.TryParse(mskbxSalBruto.Text.Replace("R$", "").Trim(), out salBruto))
            {
                if (salBruto <= 0)
                    MessageBox.Show("ERRO! Salário bruto inválido!");
                else
                {
                    if (salBruto <= 800.47)
                    {
                        txtInss.Text = "7,65%";
                        descInss = 0.0765 * salBruto;
                    }
                    else if (salBruto <= 1050)
                    {
                        txtInss.Text = "8.65%";
                        descInss = 0.0865 * salBruto;
                    }
                    else if (salBruto <= 1400.77)
                    {
                        txtInss.Text = "9%";
                        descInss = 0.09 * salBruto;
                    }
                    else if (salBruto <= 2801.56)
                    {
                        txtInss.Text = "11%";
                        descInss = 0.11 * salBruto;
                    }
                    else
                    {
                        txtInss.Text = "Teto fixo (11%)";
                        descInss = 308.17;
                    }

                    txtDescInss.Text = descInss.ToString("N2");

                    if (salBruto <= 1257.12)
                    {
                        txtIrff.Text = "Isento";
                        descIrff = 0;
                    }
                    else if (salBruto <= 2512.08)
                    {
                        txtIrff.Text = "15%";
                        descIrff = 0.15 * salBruto;
                    }
                    else
                    {
                        txtIrff.Text = "27.5%";
                        descIrff = 0.275 * salBruto;
                    }

                    txtDescIrff.Text = descIrff.ToString("N2");

                    if (salBruto <= 435.52)
                    {
                        salFam = 22.33 * Convert.ToDouble(cbxFilhos.SelectedItem);
                        txtSalFam.Text = salFam.ToString("N2");
                    }
                    else if (salBruto <= 654.61)
                    {
                        salFam = 15.74 * Convert.ToDouble(cbxFilhos.SelectedItem);
                        txtSalFam.Text = salFam.ToString("N2");
                    }
                    else
                    {
                        salFam = 0;
                        txtSalFam.Text = salFam.ToString("N2");
                    }

                    salLiq = salBruto - descInss - descIrff + salFam;
                    txtSalLiq.Text = salLiq.ToString("N2");

                    lblDados.Visible = true;

                    /**lblDados.Text = "Descontos de salário: ";

                    if (rbntFem.Checked)
                        lblDados.Text = lblDados.Text + "da Sra. " + txtFunc.Text;
                    else
                        lblDados.Text = lblDados.Text + "do Sr. " + txtFunc.Text;

                    lblDados.Text = lblDados.Text + " que é ";

                    if (ckbxCasado.Checked)
                        lblDados.Text = lblDados.Text + "casado(a)";
                    else
                        lblDados.Text = lblDados.Text + "solteiro(a)";

                    lblDados.Text = lblDados.Text + " e possui " +
                    cbxFilhos.SelectedItem.ToString() + " dependentes são: ";
                    **/
                }

                lblDados.Text = "Descontos de salário " + (rbntFem.Checked ? " da sra. " :
                    " do sr. ") + txtFunc.Text + (ckbxCasado.Checked ? " casado(a)" :
                    " solteiro(a)") + " e que tem " + cbxFilhos.SelectedItem + " dependentes são: ";
            }
            else
                MessageBox.Show("ERRO! Salário Bruto está inválido!");

        }

        private void txtFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("ERRO! Campo de dados específico para letras!");
                e.KeyChar ='\0';
            }

        }

        private void Salario_Load(object sender, EventArgs e)
        {
            cbxFilhos.SelectedIndex = 0;
        }

        private void txtFunc_Validated(object sender, EventArgs e)
        {
           // if ((txtFunc.Text == "") || (txtFunc.Text.Length < 10))
               // MessageBox.Show("ERRO! Nome do funcionário inválido");
           // txtFunc.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtDescInss.Clear();
            txtDescIrff.Clear();
            txtSalFam.Clear();
            txtInss.Clear();
            txtIrff.Clear();
            txtSalLiq.Clear();
            txtFunc.Text = "";
            mskbxSalBruto.Text = "";
            txtFunc.Text = String.Empty;
            mskbxSalBruto.Text = String.Empty;

            txtFunc.Focus();
            mskbxSalBruto.Focus();
        }
    }
}
