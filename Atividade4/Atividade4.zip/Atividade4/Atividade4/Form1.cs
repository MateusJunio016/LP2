﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        double A, B, C;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out A))
            {
                MessageBox.Show("ERRO! Valor de A Inválido!");
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtB.Text, out B))
            {
                MessageBox.Show("ERRO! Valor de B Inválido!");
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtC.Text, out C))
            {
                MessageBox.Show("ERRO! Valor de C Inválido!");
            }
        }


        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out A) ||
                !double.TryParse(txtB.Text, out B) ||
                !double.TryParse(txtC.Text, out C))
            {
                MessageBox.Show("ERRO! Valores Inválidos, digite apenas números!");
            }
            else
            {
                if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) &&
                    B > Math.Abs(A - C) && C < (A + B) && C > Math.Abs(A - B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }

                }
                else
                {
                    if (A == B && B != C || A == C && C != B || B == C && C != A)
                    {
                        MessageBox.Show("Triângulo Isóceles");
                    }
                    else if (A != B && B != C)
                    {
                        MessageBox.Show("Escaleno");
                    }

                

                    else
                    {
                        MessageBox.Show("ERRO! Valores inválidos para um triângulo");
                    }
                }
                    }

                }






            }
        }
    
