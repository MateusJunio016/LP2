﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void rtxTexto_TextChanged(object sender, EventArgs e)
        {
            

        }
            private void btnAcha_Click(object sender, EventArgs e)
            {
            int contador = 0;
            while (contador < rtxTexto.Text.Length)
            {
                if (Char.IsWhiteSpace(rtxTexto.Text[contador]))
                {
                    contador += 1;
                    break;
                }

                contador++;
            }
            MessageBox.Show("A posição do primeiro espaço em branco é: " + contador);
            }

        private void btnVerifica1_Click(object sender, EventArgs e)
        {
            int contador2 = 0;
            for (int i = 0; i < rtxTexto.Text.Length; i++)
            {

                if (Char.IsNumber(rtxTexto.Text[i]))
                    contador2++;

                
            }
            MessageBox.Show("Total de caracteres numéricos: " + contador2);
        }

        private void btnVerifica2_Click(object sender, EventArgs e)
        {
            int contador3 = 0;
            foreach(char letras in rtxTexto.Text)
            {

                if (Char.IsLetter(letras))
                    contador3++;


            }
            MessageBox.Show("Total de caracteres alfabéticos: " + contador3);
        }
    }
}
