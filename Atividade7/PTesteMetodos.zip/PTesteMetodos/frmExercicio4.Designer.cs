﻿
namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerifica2 = new System.Windows.Forms.Button();
            this.btnAcha = new System.Windows.Forms.Button();
            this.btnVerifica1 = new System.Windows.Forms.Button();
            this.rtxTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnVerifica2
            // 
            this.btnVerifica2.BackColor = System.Drawing.Color.Silver;
            this.btnVerifica2.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnVerifica2.Location = new System.Drawing.Point(566, 267);
            this.btnVerifica2.Name = "btnVerifica2";
            this.btnVerifica2.Size = new System.Drawing.Size(155, 60);
            this.btnVerifica2.TabIndex = 13;
            this.btnVerifica2.Text = "Verifica quantas letras tem";
            this.btnVerifica2.UseVisualStyleBackColor = false;
            this.btnVerifica2.Click += new System.EventHandler(this.btnVerifica2_Click);
            // 
            // btnAcha
            // 
            this.btnAcha.BackColor = System.Drawing.Color.Silver;
            this.btnAcha.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAcha.Location = new System.Drawing.Point(318, 267);
            this.btnAcha.Name = "btnAcha";
            this.btnAcha.Size = new System.Drawing.Size(168, 60);
            this.btnAcha.TabIndex = 12;
            this.btnAcha.Text = "Acha a posição do espaço em branco";
            this.btnAcha.UseVisualStyleBackColor = false;
            this.btnAcha.Click += new System.EventHandler(this.btnAcha_Click);
            // 
            // btnVerifica1
            // 
            this.btnVerifica1.BackColor = System.Drawing.Color.Silver;
            this.btnVerifica1.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnVerifica1.Location = new System.Drawing.Point(102, 267);
            this.btnVerifica1.Name = "btnVerifica1";
            this.btnVerifica1.Size = new System.Drawing.Size(146, 60);
            this.btnVerifica1.TabIndex = 11;
            this.btnVerifica1.Text = "Verifica quantos números tem";
            this.btnVerifica1.UseVisualStyleBackColor = false;
            this.btnVerifica1.Click += new System.EventHandler(this.btnVerifica1_Click);
            // 
            // rtxTexto
            // 
            this.rtxTexto.Location = new System.Drawing.Point(161, 52);
            this.rtxTexto.Name = "rtxTexto";
            this.rtxTexto.Size = new System.Drawing.Size(477, 162);
            this.rtxTexto.TabIndex = 14;
            this.rtxTexto.Text = "";
            this.rtxTexto.TextChanged += new System.EventHandler(this.rtxTexto_TextChanged);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtxTexto);
            this.Controls.Add(this.btnVerifica2);
            this.Controls.Add(this.btnAcha);
            this.Controls.Add(this.btnVerifica1);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerifica2;
        private System.Windows.Forms.Button btnAcha;
        private System.Windows.Forms.Button btnVerifica1;
        private System.Windows.Forms.RichTextBox rtxTexto;
    }
}