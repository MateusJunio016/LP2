﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        Double Num1, Num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out Num2))
            {
                MessageBox.Show("ERRO! Número 2 Inválido!");
            }
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            string num;
            string[] nums = new string[] { txtNumero1.Text, txtNumero2.Text};
            Random r = new Random();

            num = nums[r.Next(nums.Length)];

            MessageBox.Show("Número sorteado: " + num);
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out Num1))
            {
                MessageBox.Show("ERRO! Número 1 Inválido!");
            }
        }
    }
}
