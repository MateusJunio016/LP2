﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3IMC
{
    public partial class Form1 : Form
    {

        double altura;
        double peso;
        double imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            

            if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtPeso.Text, out peso))
            {
                if ((altura <= 0) || (peso <= 0))
                    MessageBox.Show("ERRO! Valores não podem ser menores ou iguais a zero");
                if (!double.TryParse(txtAltura.Text, out altura))
                {
                    MessageBox.Show("ERRO! Altura Inválida!");
                }
                if (!double.TryParse(txtPeso.Text, out peso))
                {
                    MessageBox.Show("ERRO! Peso Inválido!");
                }
                else
                {
                    imc = peso / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1);
                    txtImc.Text = imc.ToString("N1");

                    if (imc == (char)0 || imc == 0)
                        MessageBox.Show("ERRO! Digite Valores Válidos!");
                    if (imc > 0 && imc < 18.5)
                        MessageBox.Show("Magreza");

                    else if (imc >= 18.5 && imc <= 24.9)
                        MessageBox.Show("Normal");

                    else if (imc >= 25 && imc <= 29.9)
                        MessageBox.Show("Sobrepeso");

                    else if (imc >= 30 && imc <= 39.9)
                        MessageBox.Show("Obesidade");

                    else if (imc > 40)
                        MessageBox.Show("Obesidade Grave");

                }
            }
        }
        private void txtPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!((e.KeyChar >= (char)48) && (e.KeyChar <= (char)57) || (e.KeyChar == 44) ||
                (e.KeyChar == 8)))

            {
                e.KeyChar = '\0';
            }
            
        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!((e.KeyChar >= (char)48) && (e.KeyChar <= (char)57) || (e.KeyChar == 44) ||
                (e.KeyChar == 8)))

            {
                e.KeyChar = '\0';
            }
        }
    }
}
