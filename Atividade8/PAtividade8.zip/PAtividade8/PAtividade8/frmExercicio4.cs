﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }
        Double Num;


        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out Num))
            {
                MessageBox.Show("ERRO! Produção Inválida!");
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out Num))
            {
                MessageBox.Show("ERRO! Salário Inválido!");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int B = 0;
            int C = 0;
            int D = 0;
            double producao = Convert.ToDouble(txtProdução.Text);
            double gratifica = Convert.ToDouble(txtGratificacao.Text);
            double sal = Convert.ToDouble(txtSalario.Text) + gratifica;
            MessageBox.Show(Convert.ToString(sal) + Convert.ToString(producao) + Convert.ToString(gratifica));

            if (producao >= 100)
            {
                B = 1;
                sal -= gratifica;
                sal += (sal * ((0.05 * B) + (0.1 * C) + (0.1 * D)));
                sal += gratifica;
            }
            if (producao >= 120)
            {
                B = 1;
                C = 1;
                sal -= gratifica;
                sal += (sal * ((0.05 * B) + (0.1 * C) + (0.1 * D)));
                sal += gratifica;
            }
            if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
                sal -= gratifica;
                sal += (sal * ((0.05 * B) + (0.1 * C) + (0.1 * D)));
                sal += gratifica;
            }
            if (sal > 7000 && gratifica == 0)
            {
                MessageBox.Show("Salário: R$7000");
            }
            else if (sal > 7000 && gratifica > 0 && producao > 150)
            {
                MessageBox.Show("Salário: R$" + 7000 + gratifica);
            }

            else
            {
                MessageBox.Show("Salário: R$" + sal);
            }
        }

        private void txtProdução_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtProdução.Text, out Num))
            {
                MessageBox.Show("ERRO! Produção Inválida!");
            }
        }

        private void lblSalario_Click(object sender, EventArgs e)
        {

        }
    }
}
