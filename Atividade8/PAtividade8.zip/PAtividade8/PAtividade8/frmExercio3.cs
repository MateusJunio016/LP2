﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercio3 : Form
    {
        public frmExercio3()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            if (txtPalavra1.Text.Length < 50)
            {
                char[] texto;
                texto = txtPalavra1.Text.Replace(" ", "").ToUpper().ToArray();
                int contador = 0;
                string inverso = "";

                for (int x = 0; x < texto.Length; x++)
                {
                    if (texto[x] == texto[texto.Length - (x + 1)])
                    {
                        contador++;
                    }
                    string palavra = "";
                    palavra = palavra + texto[x];
                }
                foreach (char i in texto)
                {
                    inverso += i;
                }

                txtPalavra1.Text = inverso;

                if (contador == texto.Length)
                {
                    MessageBox.Show("É um Palindromo");
                }
                else
                {
                    MessageBox.Show("Não é Palindromo!");
                }
            }
            else
                MessageBox.Show("Erro! Limite de 50 caracteres ultrapassado");
    }
    }
}
