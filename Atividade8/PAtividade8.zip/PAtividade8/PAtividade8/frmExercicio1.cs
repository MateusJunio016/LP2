﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnAcha_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (int i = 0; i < rtxTexto.Text.Length; i++)
            {

                if (Char.IsWhiteSpace(rtxTexto.Text[i]))
                    contador++;


            }
            MessageBox.Show("Total de espaços em branco: " + contador);
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            char[] leitura = rtxTexto.Text.ToArray();
            int contador2 = 0;

            foreach (char i in leitura)
            {
                if (i == 'R' || i == 'r')
                    contador2++;
            }

            MessageBox.Show("Total de letras R na frase: " + contador2);
        }

        private void btnCaracteres_Click(object sender, EventArgs e)
        {
            int contador3 = 0;
            int leitura = 1;
            char[] texto = rtxTexto.Text.ToCharArray();

            while (leitura < rtxTexto.Text.Length)
            {
                if (texto[leitura] == texto[leitura - 1])
                {
                    contador3 = contador3 + 1;
                }
                leitura++;
            }

            MessageBox.Show("Total de letras pares existentes: " + contador3);
        }
    }
}
