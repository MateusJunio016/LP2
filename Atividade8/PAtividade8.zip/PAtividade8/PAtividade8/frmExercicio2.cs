﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            double h = 0;
            double n;
            double d;
            if (!double.TryParse(txtN.Text, out d))
            {
                MessageBox.Show("Erro! Número inválido");
            }
            else
            {
                n = Convert.ToDouble(txtN.Text);
                if (n <= 0)
                {
                    n = Convert.ToDouble(txtN.Text);
                    MessageBox.Show("Erro! Digite um número 'N' maior que 0");
                }
                for (double i = 1.0; i <= n + 0.0; i++)
                {
                    h = h + 1.0 / i;
                }


                MessageBox.Show("Número H = " + h);

                h = 0.0;
            }
        }
    }
}

