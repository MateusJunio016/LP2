﻿namespace PAtividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxTexto = new System.Windows.Forms.RichTextBox();
            this.btnAcha = new System.Windows.Forms.Button();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.btnCaracteres = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxTexto
            // 
            this.rtxTexto.Location = new System.Drawing.Point(231, 132);
            this.rtxTexto.Name = "rtxTexto";
            this.rtxTexto.Size = new System.Drawing.Size(307, 116);
            this.rtxTexto.TabIndex = 0;
            this.rtxTexto.Text = "";
            // 
            // btnAcha
            // 
            this.btnAcha.Location = new System.Drawing.Point(181, 309);
            this.btnAcha.Name = "btnAcha";
            this.btnAcha.Size = new System.Drawing.Size(111, 52);
            this.btnAcha.TabIndex = 1;
            this.btnAcha.Text = "Contar Espaços em branco";
            this.btnAcha.UseVisualStyleBackColor = true;
            this.btnAcha.Click += new System.EventHandler(this.btnAcha_Click);
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(342, 309);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(104, 52);
            this.btnVerifica.TabIndex = 2;
            this.btnVerifica.Text = "Contar Letras \"R\'s\"";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // btnCaracteres
            // 
            this.btnCaracteres.Location = new System.Drawing.Point(492, 309);
            this.btnCaracteres.Name = "btnCaracteres";
            this.btnCaracteres.Size = new System.Drawing.Size(107, 52);
            this.btnCaracteres.TabIndex = 3;
            this.btnCaracteres.Text = "Contar total de Caracteres";
            this.btnCaracteres.UseVisualStyleBackColor = true;
            this.btnCaracteres.Click += new System.EventHandler(this.btnCaracteres_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracteres);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.btnAcha);
            this.Controls.Add(this.rtxTexto);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxTexto;
        private System.Windows.Forms.Button btnAcha;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.Button btnCaracteres;
    }
}