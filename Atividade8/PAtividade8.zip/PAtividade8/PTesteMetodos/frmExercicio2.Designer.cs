﻿
namespace PTesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumN = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.btnGerar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNumN
            // 
            this.lblNumN.AutoSize = true;
            this.lblNumN.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumN.Location = new System.Drawing.Point(231, 98);
            this.lblNumN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumN.Name = "lblNumN";
            this.lblNumN.Size = new System.Drawing.Size(21, 19);
            this.lblNumN.TabIndex = 0;
            this.lblNumN.Text = "N";
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(260, 98);
            this.txtN.Margin = new System.Windows.Forms.Padding(4);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(127, 27);
            this.txtN.TabIndex = 2;
            // 
            // btnGerar
            // 
            this.btnGerar.BackColor = System.Drawing.Color.Silver;
            this.btnGerar.Location = new System.Drawing.Point(260, 168);
            this.btnGerar.Name = "btnGerar";
            this.btnGerar.Size = new System.Drawing.Size(119, 60);
            this.btnGerar.TabIndex = 5;
            this.btnGerar.Text = "Gerar Número H";
            this.btnGerar.UseVisualStyleBackColor = false;
            this.btnGerar.Click += new System.EventHandler(this.btnGerar_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1029, 570);
            this.Controls.Add(this.btnGerar);
            this.Controls.Add(this.txtN);
            this.Controls.Add(this.lblNumN);
            this.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.Load += new System.EventHandler(this.frmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumN;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Button btnGerar;
    }
}