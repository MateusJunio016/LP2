﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        Double Num;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        int B, C, D = 0;

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtProducao.Text, out Num))
            {
                MessageBox.Show("ERRO! Produção Inválida!");
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out Num))
            {
                MessageBox.Show("ERRO! Salário Inválido!");
            }
        }

        private void txtGratifica_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratifica.Text, out Num))
            {
                MessageBox.Show("ERRO! Gratificação Inválida!");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double producao = Convert.ToDouble(txtProducao.Text);
            double gratifica = Convert.ToDouble(txtGratifica.Text);
            double sal = Convert.ToDouble(txtSalario.Text);

            if (producao >= 100)
            {
                B = 1;
                sal = sal + (sal * (0.05 * B + 0.1 * C + 0.1 * D)) + gratifica;
            }
            if (producao >= 120)
            {
                B = 1;
                C = 1;
                sal = sal + (sal * (0.05 * B + 0.1 * C + 0.1 * D)) + gratifica;
            }
            if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
                sal = sal + (sal * (0.05 * B + 0.1 * C + 0.1 * D)) + gratifica;
            }
            if (sal > 7000 && gratifica == 0)
            {
                MessageBox.Show("Salário: R$7000");
            }
            else if (sal > 7000 && gratifica == 1 && producao > 150)
            {
                MessageBox.Show("Salário: R$" + 7000 + gratifica);
            }

            else
            {
                MessageBox.Show("Salário: R$" + sal);
            }
        }

    }
}
