﻿
namespace PTesteMetodos
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerifica2 = new System.Windows.Forms.Button();
            this.btnAcha = new System.Windows.Forms.Button();
            this.btnVerifica1 = new System.Windows.Forms.Button();
            this.rtxTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnVerifica2
            // 
            this.btnVerifica2.BackColor = System.Drawing.Color.Silver;
            this.btnVerifica2.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnVerifica2.Location = new System.Drawing.Point(566, 267);
            this.btnVerifica2.Name = "btnVerifica2";
            this.btnVerifica2.Size = new System.Drawing.Size(155, 76);
            this.btnVerifica2.TabIndex = 13;
            this.btnVerifica2.Text = "Verificar quantos  pares de letras existem";
            this.btnVerifica2.UseVisualStyleBackColor = false;
            this.btnVerifica2.Click += new System.EventHandler(this.btnVerifica2_Click);
            // 
            // btnAcha
            // 
            this.btnAcha.BackColor = System.Drawing.Color.Silver;
            this.btnAcha.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAcha.Location = new System.Drawing.Point(140, 267);
            this.btnAcha.Name = "btnAcha";
            this.btnAcha.Size = new System.Drawing.Size(168, 76);
            this.btnAcha.TabIndex = 12;
            this.btnAcha.Text = "Verificar Quantidades de Espaços em Branco";
            this.btnAcha.UseVisualStyleBackColor = false;
            this.btnAcha.Click += new System.EventHandler(this.btnAcha_Click);
            // 
            // btnVerifica1
            // 
            this.btnVerifica1.BackColor = System.Drawing.Color.Silver;
            this.btnVerifica1.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnVerifica1.Location = new System.Drawing.Point(353, 267);
            this.btnVerifica1.Name = "btnVerifica1";
            this.btnVerifica1.Size = new System.Drawing.Size(146, 76);
            this.btnVerifica1.TabIndex = 11;
            this.btnVerifica1.Text = "Verificar quantos letras \"R\" existem";
            this.btnVerifica1.UseVisualStyleBackColor = false;
            this.btnVerifica1.Click += new System.EventHandler(this.btnVerifica1_Click);
            // 
            // rtxTexto
            // 
            this.rtxTexto.Location = new System.Drawing.Point(188, 52);
            this.rtxTexto.Name = "rtxTexto";
            this.rtxTexto.Size = new System.Drawing.Size(477, 162);
            this.rtxTexto.TabIndex = 14;
            this.rtxTexto.Text = "";
            this.rtxTexto.TextChanged += new System.EventHandler(this.rtxTexto_TextChanged);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtxTexto);
            this.Controls.Add(this.btnVerifica2);
            this.Controls.Add(this.btnAcha);
            this.Controls.Add(this.btnVerifica1);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerifica2;
        private System.Windows.Forms.Button btnAcha;
        private System.Windows.Forms.Button btnVerifica1;
        private System.Windows.Forms.RichTextBox rtxTexto;
    }
}