﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }


        private void btnGerar_Click(object sender, EventArgs e)
        {
            double h = 0;
            double n = Convert.ToDouble(txtN.Text);

            if (n <= 0)
            {
                MessageBox.Show("Erro! Digite um número 'N' maior que 0");
            }
            for (double i = 1.0; i <= n + 0.0; i++)
                {
                    h = h + 1.0 / i;
                }

            
                MessageBox.Show("Número H = " + h);

                h = 0.0;
            }

        }
    }

