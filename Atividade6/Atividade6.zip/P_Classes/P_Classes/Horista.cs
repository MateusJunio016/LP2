﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P_Classes
{
    class Horista : Empregado
    {
        public int NumeroHora { get; set;  }

        public int SalarioHora { get; set; }

        public int DiasFalta { get; set; }

        public override double SalarioBruto()
        {
            return NumeroHora * SalarioHora;
        }

        public override int TempoTrabalho()
        {
            TimeSpan ts = DateTime.Today.Subtract(DataEntradaEmpresa);
            return ts.Days - DiasFalta;
        }
    }
}
