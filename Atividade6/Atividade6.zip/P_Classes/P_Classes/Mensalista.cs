﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P_Classes
{
    class Mensalista : Empregado
    {
        public int SalarioMensal { get; set; }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        public Mensalista()
        {
            //System.Windows.Forms.MessageBox.Show("Passei");
        }

        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = (int)salx;
        }

        public int Soma(int x, int y)
        {
            return x + y;
        }

        public int Soma(int x, int y, int z)
        {
            return x + y + z;
        }
    }
}
